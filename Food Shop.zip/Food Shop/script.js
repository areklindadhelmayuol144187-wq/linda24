// ============ Crumb Riot — interactions ============

// Sticky navbar shadow on scroll
const navbar = document.getElementById('navbar');
const onScroll = () => {
  if (window.scrollY > 12) {
    navbar.classList.add('scrolled');
  } else {
    navbar.classList.remove('scrolled');
  }
};
window.addEventListener('scroll', onScroll, { passive: true });
onScroll();

// Mobile nav toggle
const navToggle = document.getElementById('navToggle');
const mobilePanel = document.getElementById('mobilePanel');

navToggle.addEventListener('click', () => {
  const isOpen = mobilePanel.classList.toggle('open');
  navToggle.classList.toggle('open', isOpen);
  navToggle.setAttribute('aria-expanded', String(isOpen));
});

// Close mobile menu when a link is tapped
mobilePanel.querySelectorAll('a').forEach(link => {
  link.addEventListener('click', () => {
    mobilePanel.classList.remove('open');
    navToggle.classList.remove('open');
    navToggle.setAttribute('aria-expanded', 'false');
  });
});

// Scroll reveal animation
const revealEls = document.querySelectorAll('.reveal');

if ('IntersectionObserver' in window) {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('in');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });

  revealEls.forEach(el => observer.observe(el));
} else {
  // Fallback: just show everything
  revealEls.forEach(el => el.classList.add('in'));
}

// Newsletter form (front-end only demo)
const newsForm = document.getElementById('newsForm');
const newsMsg = document.getElementById('newsMsg');

if (newsForm) {
  newsForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const input = newsForm.querySelector('input[type="email"]');
    if (input && input.value) {
      newsMsg.textContent = `You're on the list — see you at the counter, ${input.value.split('@')[0]}.`;
      newsForm.reset();
    }
  });
}
